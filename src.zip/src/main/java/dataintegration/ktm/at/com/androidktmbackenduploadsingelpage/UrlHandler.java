package dataintegration.ktm.at.com.androidktmbackenduploadsingelpage;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UrlHandler {
    OkHttpClient client = new OkHttpClient();
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    // code request code here
    String doGetRequest(String url) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();
        return response.body().string();

    }
    String buildJson(String lat, String longitude) {
        return "{\n" +
                "  \"id\": \"string\",\n" +
                "  \"createdAt\": \"2018-06-20T14:17:28.792Z\",\n" +
                "  \"updatedAt\": \"2018-06-20T14:17:28.792Z\",\n" +
                "  \"version\": \"string\",\n" +
                "  \"deleted\": true,\n" +
                "  \"text\": " + lat + ", " + longitude + ",\n" +
                "  \"complete\": true\n" +
                "}";
    }

    String doPostRequest(String url, String json) throws IOException {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        return response.body().string();
    }
}
