package dataintegration.ktm.at.com.androidktmbackenduploadsingelpage;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//import com.microsoft.windowsazure.mobileservices.MobileServiceClient;
//import com.microsoft.windowsazure.mobileservices.table.MobileServiceTable;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Calendar;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");
    private static final long MIN_TIME = 1000 * 60 * 1;
    public Location loc = null;
    public String mURL = "https://ktmbackendupload.azurewebsites.net/tables/todoitem";

    //"https://backendupload.azurewebsites.net/tables/todoitem";
    //https://ktmbackendupload.azurewebsites.net
    private TextView mTextView;
    private ToDoItem mItem;
    //private MobileServiceClient mClient;
    //private MobileServiceTable<ToDoItem> mToDoTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                            PackageManager.PERMISSION_GRANTED) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.INTERNET},
                        1);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        Button captureGPS = findViewById(R.id.button);
        Button send2Azure = findViewById(R.id.button2);
        Button getfromAzure = findViewById(R.id.button3);

		//try {
	//		// Create the Mobile Service Client instance, using the provided
	//		// Mobile Service URL and key
	//		//mClient = new MobileServiceClient(mURL,"0",this);
//
    //  // Get the Mobile Service Table instance to use
	//		mToDoTable = mClient.getTable(ToDoItem.class);
	//	} catch (MalformedURLException e) {
	//	    System.out.println(e.getMessage());
	//	}

        mTextView = findViewById(R.id.textView);
        mTextView.setMovementMethod(new ScrollingMovementMethod());

        final MyLocationListener myLocationListener = new MyLocationListener();

        final LocationManager locationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE);

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, myLocationListener);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, myLocationListener);

        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, 0, myLocationListener);

            if (locationManager != null) {
                loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }
        } catch (SecurityException se) {
            System.out.println(se.getMessage());
        }

        captureGPS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (loc != null) {
                    String locationString = "Location: Lat: " + loc.getLatitude() + ", Lng: " + loc.getLongitude();

                    Toast.makeText(
                            v.getContext(),
                            locationString, Toast.LENGTH_SHORT).show();
                    mTextView.setText(locationString);

                }
                else
                {
                    Toast.makeText(
                            v.getContext(),
                            "No GPS signal", Toast.LENGTH_LONG).show();

                }
            }
        });

        if (loc != null) {
            String locationString = "Location: Lat: " + loc.getLatitude() + ", Lng: " + loc.getLongitude();
            mTextView.setText(locationString);
        }

        getfromAzure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(
                        v.getContext(),
                        "Getting data from KTM Backend", Toast.LENGTH_SHORT).show();
                try {
                    getRequest();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        send2Azure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(
                        v.getContext(),
                        "Sending data to KTM Backend", Toast.LENGTH_SHORT).show();
                try {
                    if (loc != null) {
                        String json_string =
                                "{" +
                                        "    \"id\":\"" + Calendar.getInstance().getTime().toString() + "\"," +
                                        "      \"version\" : \"c3RyaW5n\"," +
                                        "      \"text\": \"" + loc.getLatitude() + ", " + loc.getLongitude() + "\"" +
                                        "}";

                        postRequest(mURL, json_string);
                    } else {
                        String json_string =
                                "{\n" +
                                        "    \"id\":\"" + Calendar.getInstance().getTime().toString() + "\",\n" +
                                        "      \"version\" : \"c3RyaW5n\",\n" +
                                        "      \"text\": \"" + "48.1023, 13.1507" + "\n" +
                                        "    }\n";

                        postRequest(mURL, json_string);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    void getRequest() throws IOException {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .header("zumo-api-version", "2.0.0")
                .url(mURL)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
                mTextView.setText("failure get request");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String myResponse = response.body().string();
                mTextView.setText(myResponse);

            }
        });
    }

    void postRequest(String postUrl, String postBody) throws IOException {
        OkHttpClient client = new OkHttpClient();

        RequestBody body = RequestBody.create(JSON, postBody);

        Request request = new Request.Builder()
                .header("zumo-api-version", "2.0.0")
                .url(postUrl)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mTextView.setText("failure sending post");
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String myResponse = response.body().string();

                mTextView.setText(myResponse);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public class MyLocationListener implements android.location.LocationListener {
        @Override
        public void onLocationChanged(Location location) {
            loc = location;
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    }
}
